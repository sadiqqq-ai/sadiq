-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 08, 2021 at 10:38 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `a&a`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `userid` varchar(10) NOT NULL,
  `productid` varchar(10) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `userid` varchar(10) NOT NULL,
  `products` varchar(100) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'true',
  `date_ordered` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `userid`, `products`, `status`, `date_ordered`) VALUES
(1, '7', '1-1#12-1#', 'true', '2021-06-08'),
(2, '7', '1-1#12-1#', 'true', '2021-06-08'),
(3, '7', '1-1#12-1#', 'true', '2021-06-08'),
(4, '7', '1-1#12-1#', 'true', '2021-06-08');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `price` varchar(10) NOT NULL,
  `desc` varchar(1000) NOT NULL,
  `avatar` varchar(100) NOT NULL,
  `alt_avatar` varchar(200) NOT NULL,
  `category` varchar(100) NOT NULL,
  `show_type` varchar(50) NOT NULL,
  `quantity` int(10) NOT NULL,
  `about` varchar(1500) NOT NULL,
  `rating` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_name`, `price`, `desc`, `avatar`, `alt_avatar`, `category`, `show_type`, `quantity`, `about`, `rating`) VALUES
(1, 'Oil Diffuser by A&A', '150.00', 'Smart WiFi Wireless Essential Oil Aromatherapy 400ml Ultrasonic Diffuser & Humidifier with Alexa & Google Home Phone App & Voice Control - Create Schedules - LED & Timer Settings', 'assets/image/sierra-smart-wireless-essential-oil-diffuser.jpg', 'assets/image/sierra1.jpg,assets/image/sierra2.jpg,assets/image/sierra3.jpg', 'Sierra Oil Diffuser', 'featured', 10, '* Intelligent Aromatherapy – A great addition to your smart home that is powered intelligently and wifi compatible. Use it like a normal diffuser or download the companion app to control features like LED color, mist intensity, timer settings, scheduling and more directly from your phone. Our smart diffuser is also Alexa and Google Home compatible and can be used with echo/tap/dot to control simply by using your voice. A large 400ml water tank allows for up to 12 hours of continuous mist.\r\n* UltraSonic Vaporizer – Our smart diffuser works by creating 360° ultra sonic frequencies that instantly atomize water and oil molecules into the air. The result is a much healthier alternative than older style heat diffusers that can damage essential oils during the heat diffusion process.\r\n* Create Schedules – Scheduling is here! Our smart diffuser allows you to create regular schedules in the app so you can get your diffuser to work at your scheduled times each day or on certain days that you choose.\r\n* Alexa & Google Home Compatible – Use our included quick start guides to connect to the app and then either to your existing Alexa or Google Home accounts. You can then use your voice to conveniently control your smart diffuser including colors, mist settings and other functions.\r\n* What\'s in the Box – 1 Sierra Modern Home Smart Diffuser, 1 Power cable, Instruction and support contact manuals.', 5),
(3, 'Roomba Vacuum Cleaner by A&A', '4,560.00', 'iRobot Roomba i7+ (i7558) WiFi connected Robot Vacuum with Automatic Dirt Disposal and Power-Lifting Suction - Ideal for Pets - Learns and Maps your Home - Voice Assistant Compatibility', 'assets/image/roomba-i7-self-cleaning-smart-robot-vacuum.jpg', 'assets/image/roomba_1.jpg,assets/image/roomba_2.jpg,assets/image/roomba_3.jpg', 'Robot Vacuum Cleaner', 'featured', 10, '* iRobot has over 30 years of robotics expertise and innovation with over 30 million home robots sold worldwide. Whether you choose Roomba, Braava or both - your floors get the specialized care they need.\r\n* Forget about vacuuming for months - For up to 60 days, the i7+ automatically empties its bin into the Clean Base Automatic Dirt Disposal with AllergenLock bags that use 4 layers of allergen blocking material to trap 99% of pollen and mold.\r\n* Cleans when, where, and how you want - With advanced navigation, the i7+ can clean messes where you want, when you want. And equally important, it can stay out of where you don’t want it to go.\r\n* Vacuums messes in the moment - Cutting-edge mapping and smart navigation allow you to send the i7+ to messes when they happen, with just a simple command to your voice assistant*. *Works with Google Assistant and Alexa enabled devices Alexa and all related logos are trademarks of Amazon.com or its affiliates. Google is a trademark of Google LLC\r\n* Small dust? Large debris? No problem - Vacuums stubborn messes with a 3-Stage Cleaning System that uses Dual Multi-Surface Rubber Brushes and 10X the Power-Lifting Suction, compared to the Roomba 600 series cleaning system.\r\n* Learns your life. Listens to your voice - Learns your cleaning habits and makes personalized suggestions. It also recommends things you might not even think of - like extra cleaning during allergy or pet shedding season.\r\n* Warranty: 2 Years for Main Robot, 1 Year for Batter', 4),
(4, 'Roku Streaming Stick by A&A', '240.00', 'Powerful & portable. 4K & HDR streaming with long range wireless. Powerful and portable, Roku Streaming Stick+ is super charged with a long range wireless receiver for 4x the range and brilliant HD, 4K, and HDR picture quality. You’ll enjoy a stronger signal for smooth streaming even in rooms farther from your router. The included voice remote features buttons to turn on your TV, control the volume, mute, and search across channels with your voice. With easy access to free TV, live news, sports, movies, and more on hundreds of free channels, there’s plenty to enjoy without spending extra.', 'assets/image/roku-streaming-stick.jpg', 'assets/image/roku_box.jpg,assets/image/roku_1.jpg,assets/image/roku_inside.png,assets/image/roku_3.jpg', 'Roku Streaming Stick', 'featured', 4, '- Brilliant 4K, HDR, and HD streaming. Note: The USB port on some TV’s may be unable to power a Streaming Stick+, if you see the on-screen warning message that appears in these cases, use a wall outlet.\r\n- Powerful, portable, exceptional wireless.\r\n- Advanced wireless receiver for 4x the range.', 3),
(5, 'Bluetooth Stuff Finder by A&A', '4,560.00', 'Tile RT-18002 Pro with Replaceable Battery, Jet Black/Graphite and White/Graphite (Pack of 2)\r\n\r\n', 'assets/image/tile-bluetooth-lost-stuff-finder.jpg', 'assets/image/tile1.jpg,assets/image/tile_3.jpg,assets/image/tile_2.jpg', 'Tile Bluetooth Tracker', 'featured', 5, '- Ring your things: Use your smartphone to make your Tile Pro ring when it\'s nearby but out of sight. Compatibility : iOS 11 or newer and Android 6.0 or newer\r\n- Find your phone: Can\'t find your phone? Simply double press the Tile button on your Tile Mate to make your phone ring, even when it’s on silent.\r\n- See it on a map: The Tile app remembers when and where you left something behind.\r\n- Community: If your Tile Pro is far, Tile members can send location updates to your app, informing where your Tile Pro is.\r\n- Battery life: Replaceable CR2032 battery is guaranteed for one year from activation. You can easily replace it yourself.', 5),
(6, 'Alexa Echo Plus by A&A', '619.00', 'Echo Plus (2nd Gen) - Premium sound with built-in smart home hub - Charcoal', 'assets/image/amazon-alexa-echo-plus.jpg', 'assets/image/alexa1.jpg,assets/image/alexa2.jpg,assets/image/alexa3.jpg', 'Alexa Echo Plus', 'latest', 5, '- Meet the Echo Plus - Same great sound as our Echo (3rd Gen) with a built-in Zigbee hub to easily setup and control your compatible smart home devices.\r\n- Enjoy premium sound - Personalize your listening experience by adjusting the equalizer settings. Or pair with a second Echo Plus (2nd Gen) or Echo (3rd Gen) for stereo sound and add more bass with an Echo Sub.\r\n- Voice control your music - Ask Alexa for a song, artist, or genre from Amazon Music, Apple Music, Spotify, Pandora, SiriusXM, and more. With multi-room music, play music on compatible Echo devices in different rooms.\r\n- Voice control your smart home - Turn on lights, adjust thermostats, lock doors, and more with compatible connected devices. Create routines to start and end your day.\r\n- Keep your family in sync - Use your Alexa devices like an intercom and talk to any room in the house with Drop In and Announcements.\r\n- Alexa has skills - With tens of thousands of skills and counting, Alexa is always getting smarter and adding new skills like tracking fitness, playing games, and more.\r\n- Designed to protect your privacy - Built with multiple layers of privacy controls, including a microphone off button that electronically disconnects the mics.', 4),
(7, 'Alarm Kit by A&A', '580.00', 'Ring Alarm 5-piece kit (2nd Gen) – home security system with optional 24/7 professional monitoring – Works with Alexa', 'assets/image/ring-smart-home-alarm-kit.jpg', 'assets/image/kit2.jpg,assets/image/kit1.jpg,assets/image/kit3.jpg', 'Home Alarm Kit', 'latest', 3, '- A great fit for condos and apartments, this kit includes one base station, one keypad, one contact sensor, one motion detector, and one range extender.\r\n- Put whole-home security at your fingertips with Ring Alarm, a do-it-yourself alarm system with optional 24/7 professional monitoring with Ring Protect Plus for $10/month for 24/7 emergency police, fire and medical response when your Ring Alarm is triggered.\r\n- Includes a more intuitive keypad with emergency buttons and smaller contact sensors to seamlessly blend into your home.\r\n- Receive mobile notifications when your system is triggered, change your Alarm modes, and monitor all your Ring devices all through the Ring app.\r\n- Choose the Ring Alarm kit that fits your needs and add additional components and accessories at any time.\r\n- Easily setup your Ring Alarm by plugging in your base station, connecting to wifi via the Ring app, and placing your sensors in their ideal locations.\r\n- Better with Alexa: Arm and disarm Ring Alarm with your voice and get mobile alerts about the sound of broken glass or smoke alarms with Alexa Guard. Call trained agents from your Echo who can request the dispatch of emergency responders with Alexa Guard Plus, included with Ring Protect Plus.', 3),
(8, 'Security Camera by A&A', '230.00', 'Arlo Essential Spotlight Camera - 2 Pack - Wireless Security, 1080p Video, Color Night Vision, 2 Way Audio, Wire-Free, Direct to WiFi No Hub Needed, Works with Alexa, White - VMC2330', 'assets/image/arloo.jpg', 'assets/image/arlobox.jpg,assets/image/arlo 3.jpg,assets/image/arlo 4.jpg', 'Arlo Security Camera', 'latest', 3, '- No hub required, connect directly to Wi-Fi\r\n- Coverage from every corner - Fast, wire-free setup (no wiring required), delivers increased installation flexibility to get the perfect camera view\r\n- Capture clear details in full high definition - Record video in 1080p for a clear picture, day or night\r\n- See more at night - See important features like faces or license plates in full color, at night, with color night vision\r\n- Smarter alerts, quicker action - Receive notifications for people, vehicles, and packages so you can take quick action such as sound the siren, call a friend or dial emergency services, with the included, Arlo Smart trial\r\n- Respond quickly - Hear and speak to visitors at your door with clear, two-way audio\r\n- Local storage option - Secure your videos directly to your Arlo base-station or SmartHub (sold separately) and view them anytime anywhere\r\n- Plays well with others - Works with Amazon Alexa, Google Assistant, Apple HomeKit and Samsung SmartThings\r\n- Arlo Smart - Includes 3-months of Arlo Smart for 30-day cloud recording, advanced object detection, rich notifications, cloud activity zones and more. Plans start at $3 per month per camera thereafter', 3),
(9, 'Caseta Smart Light by A&A', '3,100.00', 'Lutron RA2 Select, Smart Home Wireless Control Dimmer Starter Kit | RRK-KITREP-2D', 'assets/image/lutron-caseta-smart-light-switch-kit.jpg', 'assets/image/caseta2.jpg,assets/image/caseta3.jpg', 'Lutron Caseta Smart Light', 'latest', 5, '- MAIN REPEATER - The RA2 Select main repeater allows for setup, control and monitoring of select lighting devices and Lutron wireless shades from a smartphone or tablet using the Lutron App.\r\n- IN-LINE DIMMER - The RA2 Select family of in-line dimmers can control lighting and motor loads both locally and remotely when paired with Pico wireless controls or Radio Power Saver occupancy/vacancy sensors.\r\n- WIRELESS CONTROLLER - Adjust lights from anywhere in a space with a Pico wireless control. This versatile and easy-to-use control requires no wires and is compatible with a wide variety of Lutron lighting and automated window treatment solutions.\r\n- SCENE KEYPAD - Adjust lights from anywhere in a space with a Pico wireless control. This versatile and easy-to-use control requires no wires and is compatible with a wide variety of Lutron lighting and automated window treatment solutions.', 3),
(10, 'Garage Opener by A&A', '150.00', '', 'assets/image/chamberlain-smart-garage-door-opener.jpg', 'assets/image/opener3.jpg,assets/image/opener2.jpg,assets/image/opener1.jpg', 'Chamberlain Garage Opener', 'latest', 8, 'Chamberlain Group B550 Smartphone-Controlled Ultra-Quiet & Strong Belt Drive Garage Door Opener with MED Lifting Power Blue\r\nThe Chamberlain B510 is a quiet, durable, steel-reinforced belt drive garage door opener. Perfect for attached garages, it’s precision engineered for years of worry-free reliability and smooth performance you can sleep through. Powered by Chamberlain’s Lift Power System, it delivers the highest lifting capacity compared to the ½ power class. Designed and engineered for safety and security, it features enhanced Triband frequency technology for superior range and performance, Security+2.0code encryption, Posi-lock protection against forced entry, dual-function wall control, wireless exterior keypad, and more. Unit accepts two 100 watt max non-halogen or 26 watt CFL light bulbs (not included). Designed specifically for 7 ft. garage doors - extension kits required for 8 ft. and 10 ft. doors.', 3),
(11, 'Amazon Smart oven by A&A', '2,100.00', 'Amazon Smart Oven, a Certified for Humans device – plus Echo Dot', 'assets/image/amazon-smart-oven.jpg', 'assets/image/oven1.jpg,assets/image/oven2.jpg,assets/image/oven3.jpg', 'Amazon Smart oven', 'latest', 12, '- Meet desertcart Smart Oven - A 4-in-1 microwave, convection oven, food warmer, and air fryer. Air fry feature may require more cooking time than standalone air fryers.\r\n- Certified for Humans - Struggle-free, tinker-free, stress-free. No patience needed—it\'s actually simple.\r\n- Preset it and forget it - Includes 30+ built-in presets, voice control with Alexa through a compatible Echo device like the included Echo Dot.\r\n- Dinner is ready - With Announcements, Alexa will notify you when the oven is preheated or when your food is done.\r\n- Check the temperature - The temperature probe helps you know when your food is cooked just the way you like it.\r\n- Scan-to-cook - Scan select packaged foods with the Alexa app and desertcart Smart Oven will cook them automatically.\r\n- Spacious interior - Large enough to cook a 5-pound chicken.\r\n- External Dimensions: 21.73 x 21.38 x 12.83 in.\r\n- Imported from USA.', 5),
(12, 'Interactive Gym by A&A', '3,469.00', 'The holy grail of home gyms is equipment that disappears when not in use,\r\n                        which is exactly what the Mirror Interactive Home Gym promises.\r\n                        It serves as a standing or wall-mounted mirror when not in use,\r\n                        but turn it on and the LCD behind the reflective surface springs to life,\r\n                        connecting you with professional trainers in stereo sound.', 'assets/image/mirror-interactive-home-gym.jpg', 'assets/image/gym1.jpg,assets/image/gym2.jpg,assets/image/gym3.jpg', 'Mirror Interactive Gym', 'exclusive', 3, 'FRAME: Carbon steel frame.\r\nMineral bronze powder coated.\r\nDISPLAY: 40” full HD 1080p display, with 178° wide viewing angle.\r\nTECHNOLOGY: Quad core processor.\r\nSOUND: 2 x 10 watt high-fidelity stereo speakers.\r\nEmbedded omnidirectional microphone.\r\nCAMERA: 5 megapixel front-facing camera.\r\nPOWER: 6 ft right angle UL certified cables.', 5);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`) VALUES
(7, 'hanis', 'hanis@gmail.com', 'hanis');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<div class="footer">
    <div class="container">
        <div class="row">
            <div class="footer-col-1">
                <h3>Download Our App</h3>
                <p>Download App for Android and ios mobile phone</p>
                <div class="app-logo">
                    <img src="assets/image/trial 2.svg">
                    <img src="assets/image/tt .svg">
                </div>
            </div>
            <div class="footer-col-2">
                <img src="assets/image/logo_size.jpg">
                <p>Our Purpose Is To sustainably make the Pleasure and
                    Benefits of Smart Homes Accessible to Many.</p>
            </div>
            <div class="footer-col-3">
                <h3>Useful Links</h3>
                <ul>
                    <li>Coupons</li>
                    <li>Blog Post</li>
                    <li>Return Policy</li>
                    <li>Join Affiliate</li>
                </ul>
            </div>
            <div class="footer-col-4">
                <h3>Follow us</h3>
                <ul>
                    <li>Faceebook</li>
                    <li><a href="https://mobile.twitter.com/sadeek__">Twitter</a></li>
                    <li>Instagram</li>
                    <li>LinkedIn</li>
                </ul>
            </div>
        </div>
        <hr>
        <p class="copyright">Copyright 2021 - Final Year Project</p>
    </div>
</div>